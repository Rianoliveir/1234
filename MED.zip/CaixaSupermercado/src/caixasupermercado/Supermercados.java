package caixasupermercado;

import java.util.ArrayList;
import java.util.List;

public class Supermercados {

    public static void main(String[] args) {
        class produtos {

            int id_produtos;
            String nome;
            double preco;
            int estoque;

            public produtos(int id_produtos, String nome, Double preco, int estoque) {
                this.id_produtos = id_produtos;
                this.nome = nome;
                this.preco = preco;
                this.estoque = estoque;

            }
        }

        class compras {

            int id_compras;
            int quantidade;
            double data;
            double total;

            List<produtos> produtoscomprados = new ArrayList<>();

            public compras(int id_compras) {
                this.id_compras = id_compras;
                this.data = data;
            }

            public double calcularValorToal() {
                double total = 0;
                for (produtos produto : produtoscomprados) {
                    total += produto.preco;
                }
                return total;
            }

        }

    }

}
