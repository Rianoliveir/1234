package caixasupermercado;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CaixaSupermercadosPrincipal {

    static List<produtos> produto = new ArrayList<>();
    static List<compras> compra = new ArrayList<>();
    static int proximoid_produtos = 1;
    static int proximoid_compras = 1;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Escolha uma opção: ");
            System.out.println("1. Adicionar produto");
            System.out.println("2. Realizar compra");
            System.out.println("3. Listar produto");
            System.out.println("4. Listar compras");
            System.out.println("5. Sair");

            int opcao = scanner.nextInt();

            switch (opcao) {
                case 1:

                adicionarProduto(); // Chamando a função para adicionar produto
                break;

                case 2:
                  adicionarCompra();
                  break;

                case 3:
                    System.out.println("Lista de Produtos:");
                    listarProdutos();
                    break;

                case 4:
                    System.out.println("Lista de Compras:");
                    listarCompras();
                    break;

                case 5:
                    System.out.println("Saindo do programa.");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Opção inválida. Tente novamente.");

            }
        }
       
    }
    
    

    
    private static void adicionarProduto() {
    Scanner scanner = new Scanner(System.in);

    System.out.print("Digite o nome do produto: ");
    String nome = scanner.next();
    System.out.print("Digite o preço do produto: ");
    double preco = scanner.nextDouble();
    System.out.print("Digite a quantidade em estoque: ");
    int quantidadeEmEstoque = scanner.nextInt();

    produtos novoProduto = new produtos(proximoid_produtos++, nome, preco, quantidadeEmEstoque);
    produto.add(novoProduto);

    System.out.println("Produto adicionado com sucesso!");
}
    
    private static void adicionarCompra() {
    compras novaCompra = new compras(proximoid_compras++);
    novaCompra.produtoscomprados = new ArrayList<>();

    System.out.println("Adicione produtos à compra (Digite o ID do produto, digite 0 para finalizar):");
    int id_produtos;
    do {
        System.out.print("Digite o ID do produto: ");
        id_produtos = scanner.nextInt();
        if (id_produtos > 0) {
            produtos produtoSelecionado = encontrarProdutoPorId(id_produtos);
            if (produtoSelecionado != null) {
                novaCompra.produtoscomprados.add(produtoSelecionado);
            } else {
                System.out.println("Produto não encontrado.");
            }
        }
    } while (id_produtos > 0);

    compra.add(novaCompra); // Adicionar à lista "compra"
}
    
    private static produtos encontrarProdutoPorId(int id_produtos) {
        for (produtos produto : produto) {
            if (produto.id_produtos == id_produtos) {
                return produto;
            }
        }
        return null;
    }

    private static void listarProdutos() {
        for (produtos produto : produto) {
            System.out.println("ID: " + produto.id_produtos + ", Nome: " + produto.nome + ", Preço: " + produto.preco + ", Estoque: " + produto.estoque);
        }
    }

    private static void listarCompras() {
        for (compras compra : compra) {
            System.out.println("ID da Compra: " + compra.id_compras + ", Valor Total: " + compra.calcularValorTotal());
        }
    }
    
}

  