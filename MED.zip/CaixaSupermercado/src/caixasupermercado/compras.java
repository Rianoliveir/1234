package caixasupermercado;

import java.util.List;

public class compras {

  

    int id_compras;
    int quantidade;
    double data;
    double total;
    double valorTotal;
    
    List<produtos>produtoscomprados;

    public compras() {
    }

    public compras(int id_compras) {
        this.id_compras = id_compras;
        this.quantidade = quantidade;
        this.data = data;
        this.total = total;
        this.valorTotal = calcularValorTotal();
    }
    
    public double calcularValorTotal(){
        double total = 0.0;
        for (produtos produto : produtoscomprados){
          total += produto.preco;
        }
        return total;
    }

    public int getId_compras() {
        return id_compras;
    }

    public void setId_compras(int id_compras) {
        this.id_compras = id_compras;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public double getData() {
        return data;
    }

    public void setData(double data) {
        this.data = data;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

}
