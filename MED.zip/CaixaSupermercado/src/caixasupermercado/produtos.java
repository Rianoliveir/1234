package caixasupermercado;

public class produtos {

    static void add(produtos novoProduto) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    int id_produtos;
    String nome;
    double preco;
    int estoque;

    public produtos() {
    }

    public produtos(int id_produtos, String nome, double preco, int estoque) {
        this.id_produtos = id_produtos;
        this.nome = nome;
        this.preco = preco;
        this.estoque = estoque;
    }

    public int getId_produtos() {
        return id_produtos;
    }

    public void setId_produtos(int id_produtos) {
        this.id_produtos = id_produtos;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getEstoque() {
        return estoque;
    }

    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

}
