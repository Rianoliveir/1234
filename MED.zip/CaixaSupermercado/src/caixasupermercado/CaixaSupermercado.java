package caixasupermercado;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class CaixaSupermercado {
    public static void main(String[]args){
        Connection connection = null;
        try {
            String url = "jdbc:mysql://localhost:3308/supermercados";
            String user = "root";
            String password = "";
           
            connection = DriverManager.getConnection(url, user, password);
           
            System.out.print("Conexao com o banco de dados estabelecida!");
           
        }catch (SQLException e){
            e.printStackTrace();    
        } finally {
            if (connection != null){
            try {
                connection.close();
            }catch (SQLException e){
                e.printStackTrace();
            }
        }
        }
       
       
       
       
       
    }
   
}